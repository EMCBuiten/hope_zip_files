def world():
	print("Hello, World! This is Emma.")
	
shark = "Sammy"